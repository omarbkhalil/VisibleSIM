#include "boxesBlockCode.hpp"

using namespace BlinkyBlocks;

BoxesBlockCode::BoxesBlockCode(BlinkyBlocksBlock *host) : BlinkyBlocksBlockCode(host) {
    // @warning Do not remove block below, as a blockcode with a NULL host might be created
    //  for command line parsing
    if (not host) return;

    // Registers a callback (handleSampleMessage) to the message of type SAMPLE_MSG_ID
    addMessageEventFunc2(D_MSG_ID,
                         std::bind(&BoxesBlockCode::handleDMessage, this,
                                   std::placeholders::_1, std::placeholders::_2));

    addMessageEventFunc2(DL_MSG_ID,
                       std::bind(&BoxesBlockCode::handleDLMessage, this,
                                 std::placeholders::_1, std::placeholders::_2));


    addMessageEventFunc2(W_MSG_ID,
                        std::bind(&BoxesBlockCode::handleWMessage, this,
                                  std::placeholders::_1, std::placeholders::_2));

    // Set the module pointer
    module = static_cast<BlinkyBlocksBlock*>(hostBlock);
  }

void BoxesBlockCode::startup() {
    console << "start";

    // Sample distance coloring algorithm below
    // if (module->blockId == 1) { // Master ID is 1
    //     module->setColor(RED);
    //     distance = 0;
    //     sendMessageToAllNeighbors("Sample Broadcast",
    //                               new MessageOf<int>(D_MSG_ID,distance),100,200,0);
    // }
 if (!lattice->cellHasBlock(module->position.offsetY(1))) {

     sendMessageToAllNeighbors("Depth Initialization",
                                    new MessageOf<int>(D_MSG_ID,dp),100,200,1);


    setColor(YELLOW);
}


    else {
        dp = -1; // Unknown distance
        hostBlock->setColor(LIGHTGREY);
    }

    // Additional initialization and algorithm start below
    // ...

    // for (int i = 0; i < module->getNbInterfaces(); i++) {
    //     P2PNetworkInterface *neighborInterface = module->getInterface(i);
    //
    //     if (i == 2 && neighborInterface && neighborInterface->connectedInterface) {
    //         // only front (+Y)
    //         sendMessageToAllNeighbors("Sample Broadcast",
    //                                new MessageOf<int>(D_MSG_ID,dp),100,200,1);
    //
    //         setColor(BLACK);
    //     }
    // }
}


void BoxesBlockCode::handleWMessage(std::shared_ptr<Message> _msg,
                                               P2PNetworkInterface* sender) {
}


void BoxesBlockCode::handleDMessage(std::shared_ptr<Message> _msg,
                                               P2PNetworkInterface* sender) {
    MessageOf<int>* msg = static_cast<MessageOf<int>*>(_msg.get());

    int d = *msg->getData() + 1;
    dp =*msg->getData();
    console << " received d =" << d << " from " << sender->getConnectedBlockId() << "\n";

    if (lattice->cellHasBlock(module->position.offsetY(-1))) {
        sendMessage("d msg", new MessageOf<int>(D_MSG_ID, d),   module->getInterfaceToNeighborPos(module->position.offsetY(-1)), 100, 200);





    }




    else {
        if (lattice->cellHasBlock(module->position.offsetX(-1)) && counter == 0) {
            counter++;
            sendMessage("received Dleft ", new MessageOf<int>(DL_MSG_ID, 0),   module->getInterfaceToNeighborPos(module->position.offsetX(-1)), 100, 200);

setColor(RED);
            // if (lattice->cellHasBlock(module->position.offsetY(-1)) ) {
            //
            // }
            // check if it is a corner
        }
    }
}



void BoxesBlockCode::handleDLMessage(std::shared_ptr<Message> _msg,
                                               P2PNetworkInterface* sender) {
    MessageOf<int>* msg = static_cast<MessageOf<int>*>(_msg.get());
    int d = *msg->getData() + 1;


    // int d = *msg->getData() ;
    // // dp = d-1;
    // console << " received d =" << d << " from " << sender->getConnectedBlockId() << "\n";
    //
    //
    //
    // sendMessage("Send the Dleft ", new MessageOf<int>(DL_MSG_ID, d),   module->getInterfaceToNeighborPos(module->position.offsetX(+1)), 100, 200);
    console << " received d from left=" << d << " from " << sender->getConnectedBlockId() << "\n";

setColor(BLACK);
    //     if (lattice->cellHasBlock(module->position.offsetY(-1))) {
    //         sendMessage("d msg", new MessageOf<int>(D_MSG_ID, d),   module->getInterfaceToNeighborPos(module->position.offsetY(-1)), 100, 200);
    //
    //
    //
    //
    //
    //     }
    //
    //     else if (d == -1) {
    //
    //         sendMessage("Send me Dleft ", new MessageOf<int>(D_MSG_ID, dp),   module->getInterfaceToNeighborPos(module->position.offsetX(+1)), 100, 200);
    //         setColor(BLACK);
    //     }
    //
    //
    //     else {
    //         if (lattice->cellHasBlock(module->position.offsetX(-1)) && counter == 0) {
    //             counter++;
    //             sendMessage("received Dleft ", new MessageOf<int>(D_MSG_ID, -2),   module->getInterfaceToNeighborPos(module->position.offsetX(-1)), 100, 200);
    //
    // setColor(RED);
    //             // if (lattice->cellHasBlock(module->position.offsetY(-1)) ) {
    //             //
    //             // }
    //             // check if it is a corner
    //         }
    //     }
}

void BoxesBlockCode::onMotionEnd() {
    console << " has reached its destination" << "\n";

    // do stuff
    // ...
}

void BoxesBlockCode::processLocalEvent(EventPtr pev) {
    std::shared_ptr<Message> message;
    stringstream info;


    // Do not remove line below
    BlinkyBlocksBlockCode::processLocalEvent(pev);

    switch (pev->eventType) {
        case EVENT_ADD_NEIGHBOR: {
            // Do something when a neighbor is added to an interface of the module
            break;
        }

        case EVENT_REMOVE_NEIGHBOR: {
            // Do something when a neighbor is removed from an interface of the module
            break;
        }
    }
}

/// ADVANCED BLOCKCODE FUNCTIONS BELOW

void BoxesBlockCode::onBlockSelected() {
    // Debug stuff:
    cerr << endl << "--- PRINT MODULE " << *module << "---" << endl;
}

void BoxesBlockCode::onAssertTriggered() {
    console << " has triggered an assert" << "\n";

    // Print debugging some info if needed below
    // ...
}

bool BoxesBlockCode::parseUserCommandLineArgument(int &argc, char **argv[]) {
    /* Reading the command line */
    if ((argc > 0) && ((*argv)[0][0] == '-')) {
        switch((*argv)[0][1]) {

            // Single character example: -b
            case 'b':   {
                cout << "-b option provided" << endl;
                return true;
            } break;

            // Composite argument example: --foo 13
            case '-': {
                string varg = string((*argv)[0] + 2); // argv[0] without "--"
                if (varg == string("foo")) { //
                    int fooArg;
                    try {
                        fooArg = stoi((*argv)[1]);
                        argc--;
                        (*argv)++;
                    } catch(std::logic_error&) {
                        stringstream err;
                        err << "foo must be an integer. Found foo = " << argv[1] << endl;
                        throw CLIParsingError(err.str());
                    }

                    cout << "--foo option provided with value: " << fooArg << endl;
                } else return false;

                return true;
            }

            default: cerr << "Unrecognized command line argument: " << (*argv)[0] << endl;
        }
    }

    return false;
}

string BoxesBlockCode::onInterfaceDraw() {
    stringstream trace;
    trace << "Some value " << 123;
    return trace.str();
}
