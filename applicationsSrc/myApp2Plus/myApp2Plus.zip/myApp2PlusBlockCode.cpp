/**
 * @file MyApp2plusBlockCode.cpp
 */

#include "MyApp2plusBlockCode.hpp"

MyApp2plusBlockCode::MyApp2plusBlockCode(BlinkyBlocksBlock *host)
: BlinkyBlocksBlockCode(host), module(host) {
    if (!host) return;

    addMessageEventFunc2(GO_MSG_ID,
        std::bind(&MyApp2plusBlockCode::myGoFunc, this,
                  std::placeholders::_1, std::placeholders::_2));

    addMessageEventFunc2(BACK_MSG_ID,
        std::bind(&MyApp2plusBlockCode::myBackFunc, this,
                  std::placeholders::_1, std::placeholders::_2));

    addMessageEventFunc2(GO2_MSG_ID,
        std::bind(&MyApp2plusBlockCode::myGo2Func, this,
                  std::placeholders::_1, std::placeholders::_2));

    addMessageEventFunc2(BACK2_MSG_ID,
        std::bind(&MyApp2plusBlockCode::myBack2Func, this,
                  std::placeholders::_1, std::placeholders::_2));
}

void MyApp2plusBlockCode::startup() {
    console << "start " << getId() << "\n";

    // Reset phase 1
    parent = nullptr; winnerChild = nullptr;
    myDistance = 0; nbWaitedAns = 0;
    bestDist = -1; bestId = 0;

    // Reset phase 2
    parent2 = nullptr; winnerChild2 = nullptr;
    myDistance2 = 0; nbWaitedAns2 = 0;
    bestDist2 = -1; bestId2 = 0;

    if (isA) {                 // Leader from XML attribute isA="true"
        myDistance = 0;
        bestDist   = 0;
        bestId     = getId();
        setColor(RED);

        // Start GO flood (phase 1)
        nbWaitedAns = sendMessageToAllNeighbors("initial go from leader",
                           new MessageOf<int>(GO_MSG_ID, 1), 1000, 0, 0);

        // Trivial single-node system: leader is also farthest; color here (winner == root)
        if (nbWaitedAns == 0) {
            // setColor(YELLOW);
            // Optionally start phase 2 from me
            parent2 = nullptr; winnerChild2 = nullptr;
            myDistance2 = 0; bestDist2 = 0; bestId2 = getId();
            nbWaitedAns2 = sendMessageToAllNeighbors("go2",
                               new MessageOf<int>(GO2_MSG_ID, 1), 1000, 0, 0);
            if (nbWaitedAns2 == 0) setColor(BLUE);
        }
    } else {
        setColor(LIGHTGREY);
    }
}

// ========================= PHASE 1 (from leader) =========================

void MyApp2plusBlockCode::myGoFunc(std::shared_ptr<Message> _msg,
                                   P2PNetworkInterface* sender) {
    auto* msg = static_cast<MessageOf<int>*>(_msg.get());
    int msgData = *msg->getData(); // distance from leader

    if (parent == nullptr) {
        // First time we get GO: adopt this sender as parent in the BFS tree
        parent      = sender;
        myDistance  = msgData;

        // Prepare aggregation (include myself as default)
        bestDist    = myDistance;
        bestId      = getId();
        winnerChild = nullptr;

        // Forward GO to all neighbors except parent; count children
        nbWaitedAns = sendMessageToAllNeighbors("go",
                           new MessageOf<int>(GO_MSG_ID, msgData + 1),
                           1000, 100, 1, sender);

        // If no children → leaf: send BACK immediately to parent
        if (nbWaitedAns == 0) {
            BackPayload b{0, myDistance, getId()}; // kind=0 ACK_UP
            sendMessage("leafBack",
                        new MessageOf<BackPayload>(BACK_MSG_ID, b),
                        parent, 1000, 100);
        }
    } else {
        // Already have a parent: tell sender I'm not your child (harmless ack)
        BackPayload b{0, -1, getId()}; // dist=-1 so it never wins aggregation
        sendMessage("reject",
                    new MessageOf<BackPayload>(BACK_MSG_ID, b),
                    sender, 1000, 100);
    }
}

void MyApp2plusBlockCode::myBackFunc(std::shared_ptr<Message> _msg,
                                     P2PNetworkInterface* sender) {
    auto* m = static_cast<MessageOf<BackPayload>*>(_msg.get());
    BackPayload bp = *m->getData();

    // SELECT_DOWN (directed down to the phase-1 winner)
    if (bp.kind == 1) {
        if (getId() == bp.id) {
            // I am the farthest from the leader
            setColor(YELLOW);

            // ---- Start PHASE 2 from me (the yellow node) ----
            parent2      = nullptr;
            winnerChild2 = nullptr;
            myDistance2  = 0;
            bestDist2    = 0;
            bestId2      = getId();

            nbWaitedAns2 = sendMessageToAllNeighbors("go2",
                               new MessageOf<int>(GO2_MSG_ID, 1), 1000, 0, 0);

            if (nbWaitedAns2 == 0) setColor(BLUE); // degenerate case
        } else if (winnerChild) {
            // Forward only along the stored branch that produced the winner
            sendMessage("selectDown",
                        new MessageOf<BackPayload>(BACK_MSG_ID, bp),
                        winnerChild, 100, 1000);
        }
        return; // do not touch nbWaitedAns on select-down
    }

    // ACK_UP from a child: aggregate farthest (max dist, tie on min id)
    if (bp.dist > bestDist || (bp.dist == bestDist && bp.id < bestId)) {
        bestDist    = bp.dist;
        bestId      = bp.id;
        winnerChild = sender;
    }

    // Count child answers
    nbWaitedAns--;
    if (nbWaitedAns == 0) {
        if (parent) {
            // Include myself if I beat children
            if (myDistance > bestDist || (myDistance == bestDist && getId() < bestId)) {
                bestDist    = myDistance;
                bestId      = getId();
                winnerChild = nullptr; // winner is me
            }

            BackPayload up{0, bestDist, bestId};
            sendMessage("backUp",
                        new MessageOf<BackPayload>(BACK_MSG_ID, up),
                        parent, 100, 1000);
        } else {
            // Root (leader) decides winner
            console << "Phase1: farthest from leader = " << bestId
                    << " at dist = " << bestDist << "\n";

            if (winnerChild) {
                // Send select-down to the branch
                BackPayload sel{1, bestDist, bestId}; // SELECT_DOWN
                sendMessage("selectDown",
                            new MessageOf<BackPayload>(BACK_MSG_ID, sel),
                            winnerChild, 100, 1000);
            } else {
                // Winner is the root itself (no child to forward to)
                // setColor(YELLOW);
                // Immediately start phase 2 from me
                parent2 = nullptr; winnerChild2 = nullptr;
                myDistance2 = 0; bestDist2 = 0; bestId2 = getId();
                nbWaitedAns2 = sendMessageToAllNeighbors("go2",
                                   new MessageOf<int>(GO2_MSG_ID, 1), 1000, 0, 0);
                // if (nbWaitedAns2 == 0) setColor(BLUE);
            }
        }
    }
}

// ========================= PHASE 2 (from yellow) =========================

void MyApp2plusBlockCode::myGo2Func(std::shared_ptr<Message> _msg,
                                    P2PNetworkInterface* sender) {
    auto* msg = static_cast<MessageOf<int>*>(_msg.get());
    int d = *msg->getData(); // distance from yellow

    if (parent2 == nullptr) {
        parent2     = sender;
        myDistance2 = d;

        // Include myself as default best
        if (bestDist2 < myDistance2 || (bestDist2 == myDistance2 && getId() < bestId2)) {
            bestDist2    = myDistance2;
            bestId2      = getId();
            winnerChild2 = nullptr;
        }

        // Forward GO2 to all except parent2
        nbWaitedAns2 = sendMessageToAllNeighbors("go2",
                           new MessageOf<int>(GO2_MSG_ID, d + 1),
                           1000, 100, 1, sender);

        if (nbWaitedAns2 == 0) {
            BackPayload b{0, myDistance2, getId()};
            sendMessage("back2-leaf",
                        new MessageOf<BackPayload>(BACK2_MSG_ID, b),
                        parent2, 1000, 100);
        }
    } else {
        // Already in some other branch of GO2; reject politely
        BackPayload b{0, -1, getId()};
        sendMessage("back2-reject",
                    new MessageOf<BackPayload>(BACK2_MSG_ID, b),
                    sender, 1000, 100);
    }
}

void MyApp2plusBlockCode::myBack2Func(std::shared_ptr<Message> _msg,
                                      P2PNetworkInterface* sender) {
    auto* m = static_cast<MessageOf<BackPayload>*>(_msg.get());
    BackPayload bp = *m->getData();

    // SELECT_DOWN for phase 2
    if (bp.kind == 1) {
        if (getId() == bp.id) {
            console << "Phase2: I am BLUE (id=" << getId()
                    << "), distance from yellow = " << bp.dist << "\n";
            setColor(BLUE); // farthest from yellow
        } else if (winnerChild2) {
            sendMessage("back2-select-down",
                        new MessageOf<BackPayload>(BACK2_MSG_ID, bp),
                        winnerChild2, 100, 1000);
        }
        return;
    }

    // ACK_UP: aggregate farthest (max dist, tie on min id)
    if (bp.dist > bestDist2 || (bp.dist == bestDist2 && bp.id < bestId2)) {
        bestDist2    = bp.dist;
        bestId2      = bp.id;
        winnerChild2 = sender;
    }

    nbWaitedAns2--;
    if (nbWaitedAns2 == 0) {
        if (parent2) {
            // Include myself if I beat children
            if (myDistance2 > bestDist2 || (myDistance2 == bestDist2 && getId() < bestId2)) {
                bestDist2    = myDistance2;
                bestId2      = getId();
                winnerChild2 = nullptr;
            }
            BackPayload up{0, bestDist2, bestId2};
            sendMessage("back2-up",
                        new MessageOf<BackPayload>(BACK2_MSG_ID, up),
                        parent2, 100, 1000);
        } else {
            // Yellow (phase-2 root) decides winner
            console << "Phase2: farthest from yellow = " << bestId2
                    << " at dist = " << bestDist2 << "\n";

            if (winnerChild2) {
                BackPayload sel{1, bestDist2, bestId2}; // SELECT_DOWN
                sendMessage("back2-select",
                            new MessageOf<BackPayload>(BACK2_MSG_ID, sel),
                            winnerChild2, 100, 1000);
            }
        }
    }
}

// ========================= XML parsing =========================

void MyApp2plusBlockCode::parseUserBlockElements(TiXmlElement *config) {
    const char *attr = config->Attribute("isA");
    if (attr != nullptr) {
        std::cout << getId() << " is isA!" << std::endl;
        isA = true;
    }
}
