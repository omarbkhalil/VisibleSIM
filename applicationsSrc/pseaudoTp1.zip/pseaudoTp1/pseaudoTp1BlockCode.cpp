#include "pseaudoTp1BlockCode.hpp"

using namespace BlinkyBlocks;



PseaudoTp1BlockCode::PseaudoTp1BlockCode(BlinkyBlocksBlock *host) : BlinkyBlocksBlockCode(host) {
    // @warning Do not remove block below, as a blockcode with a NULL host might be created
    //  for command line parsing
    if (not host) return;

    // Registers a callback (handleSampleMessage) to the message of type SAMPLE_MSG_ID
    addMessageEventFunc2(SAMPLE_MSG_ID,
                         std::bind(&PseaudoTp1BlockCode::handleSampleMessage, this,
                                   std::placeholders::_1, std::placeholders::_2));

    // Set the module pointer
    module = static_cast<BlinkyBlocksBlock*>(hostBlock);
  }



void PseaudoTp1BlockCode::startup() {
    console << "start";

    // Sample distance coloring algorithm below
    // if (module->blockId == 1) { // Master ID is 1
    //     module->setColor(RED);
    //     distance = 0;
    //     sendMessageToAllNeighbors("Sample Broadcast",
    //                               new MessageOf<int>(SAMPLE_MSG_ID,distance),100,200,0);
    // }
    // else
    if  (isInitiator()) {
        setColor(BLACK);

        initiatorPositions.push_back(module->position);

        //Start NextDirFunc

        int nextDir = getNextDir(module->position, FRONT);

        MyMsgData data{nextDir, initiatorPositions, module->position};

        sendMessageToAllNeighbors("go",
            new MessageOf<MyMsgData>(SAMPLE_MSG_ID, data),
            0, 0, 1);


    }

    else {
        distance = -1; // Unknown distance
        hostBlock->setColor(LIGHTGREY);
    }

    // Additional initialization and algorithm start below
    // ...


}


// int  PseaudoTp1BlockCode::getNextDir(Direction prevDir) {
//     static std::array<Direction, 4> directions = {FRONT, RIGHT, BACK, LEFT};
//     int idx = (int)prevDir;
//     return directions[(idx + 1) % directions.size()];
// }

int PseaudoTp1BlockCode::getNextDir(const Cell3DPosition& P, int prevDir) {
    int k = (prevDir + 3) % 4;  // turn left first

    for (int i = 0; i < 4; i++) {
        Cell3DPosition Q;
        switch (k) {
            case FRONT: Q = Cell3DPosition(P[0],   P[1] + 1, P[2]); break;
            case RIGHT: Q = Cell3DPosition(P[0] + 1, P[1],   P[2]); break;
            case BACK:  Q = Cell3DPosition(P[0],   P[1] - 1, P[2]); break;
            case LEFT:  Q = Cell3DPosition(P[0] - 1, P[1],   P[2]); break;
        }

        if (lattice->cellHasBlock(Q)) {
            if (module->getInterfaceToNeighborPos(Q) != nullptr) {
                return k; // found next border direction
            }
        }

        k = (k + 1) % 4;  // rotate clockwise
    }

    return prevDir; // fallback
}
bool PseaudoTp1BlockCode::isInitiator() {
    // if ((module->position == Cell3DPosition(module->position[0], module->position[1]-1, module->position[2])) && (module->position == Cell3DPosition(module->position[0] -1, module->position[1], module->position[2])) ||(module->position != Cell3DPosition(module->position[0]+1, module->position[1]-1, module->position[2]))) {

    return ( !lattice->cellHasBlock(module->position.offsetY(-1)) &&
         ( !lattice->cellHasBlock(module->position.offsetX(-1)) ||
           lattice->cellHasBlock(module->position.offsetX(+1).offsetY(-1)) ) );

}

//
// void PseaudoTp1BlockCode::handleSampleMessage(std::shared_ptr<Message> _msg,
//                                                P2PNetworkInterface* sender) {
//     MessageOf<MyMsgData>* msg = static_cast<MessageOf<MyMsgData>*>(_msg.get());
//     MyMsgData data = *msg->getData();
//     int prevDir = data.dir;
//
//     console << "Received msg: dir=" << data.dir
//             << " flag=" << data.initiatorP
//             << " from " << sender->getConnectedBlockId() << "\n";
//
//     if (data.dir == getNextDir(data.initiatorP, FRONT)) {
//         console << "Flag is set\n";
//         setColor(GREEN);
//     }
//
//
//     if (data.initiatorP== module->position) {
//         // initiatorPositions.push_back(module->position);
// return;
//
//
//     }
// if (prevDir == getNextDir(data.initiatorP, FRONT)) {
//
// }
//
//
//     // if (data.initiatorP == module->position) {
//     //     console << "Flag is set\n";
//     //     setColor(GREEN);
//     // }
//
//     // if (distance == -1 || distance > d) {
//     //     console << " updated distance = " << d << "\n";
//     //     distance = d;
//     //     // module->setColor(Colors[distance % NB_COLORS]);
//     //
//     //     // Broadcast to all neighbors but ignore sender
//     //     sendMessageToAllNeighbors("Sample Broadcast",
//     //                               new MessageOf<int>(SAMPLE_MSG_ID,distance),100,200,1,sender);
//     // }
// }
//
void PseaudoTp1BlockCode::onMotionEnd() {
    console << " has reached its destination" << "\n";

    // do stuff
    // ...
}


void PseaudoTp1BlockCode::handleSampleMessage(std::shared_ptr<Message> _msg,
                                              P2PNetworkInterface* sender) {
    // Unpack message
    MessageOf<MyMsgData>* msg = static_cast<MessageOf<MyMsgData>*>(_msg.get());
    MyMsgData data = *msg->getData();



    int prevDir = data.dir;
    Cell3DPosition initiatorPos = data.initiatorP;

    console << "Received BORDER msg: dir=" << prevDir
            << " initiator=" << initiatorPos
            << " from " << sender->getConnectedBlockId() << "\n";

    // --- Termination condition ---
    if (initiatorPos == module->position) {
        console << ">>> Border completed at initiator " << initiatorPos << "\n";
        setColor(RED);
        return;
    }

    else if (prevDir == FRONT){
        setColor(GREEN);
    // --- Forward only if unseen or smaller initiator ---
    // if (dirInit.find(prevDir) == dirInit.end() ||
    //     isLess(initiatorPos, dirInit[prevDir]))
    // {
    //     // update stored initiator for this direction
    //     dirInit[prevDir] = initiatorPos;
    //
    //     // Compute next direction based on border rule
    //     Direction nextDir = (Direction)getNextDir(module->position, prevDir);
    //
    //     // Forward message to neighbors
    //     MyMsgData forward{nextDir, initiatorPositions, initiatorPos};
    //     sendMessageToAllNeighbors("Border search",
    //         new MessageOf<MyMsgData>(SAMPLE_MSG_ID, forward),
    //         100, 200, 1, sender);
    //
    //     setColor(GREEN);
    // } else {
        console << "Message ignored (better initiator already stored)\n";
    }
}


bool PseaudoTp1BlockCode::isLess(const Cell3DPosition& a, const Cell3DPosition& b) {
    if (a[0] < b[0]) return true;
    if (a[0] == b[0] && a[1] < b[1]) return true;
    return false;
}



void PseaudoTp1BlockCode::processLocalEvent(EventPtr pev) {
    std::shared_ptr<Message> message;
    stringstream info;

    // Do not remove line below
    BlinkyBlocksBlockCode::processLocalEvent(pev);

    switch (pev->eventType) {
        case EVENT_ADD_NEIGHBOR: {
            // Do something when a neighbor is added to an interface of the module
            break;
        }

        case EVENT_REMOVE_NEIGHBOR: {
            // Do something when a neighbor is removed from an interface of the module
            break;
        }
    }
}

/// ADVANCED BLOCKCODE FUNCTIONS BELOW

void PseaudoTp1BlockCode::onBlockSelected() {
    // Debug stuff:
    cerr << endl << "--- PRINT MODULE " << *module << "---" << endl;
}

void PseaudoTp1BlockCode::onAssertTriggered() {
    console << " has triggered an assert" << "\n";

    // Print debugging some info if needed below
    // ...
}

bool PseaudoTp1BlockCode::parseUserCommandLineArgument(int &argc, char **argv[]) {
    /* Reading the command line */
    if ((argc > 0) && ((*argv)[0][0] == '-')) {
        switch((*argv)[0][1]) {

            // Single character example: -b
            case 'b':   {
                cout << "-b option provided" << endl;
                return true;
            } break;

            // Composite argument example: --foo 13
            case '-': {
                string varg = string((*argv)[0] + 2); // argv[0] without "--"
                if (varg == string("foo")) { //
                    int fooArg;
                    try {
                        fooArg = stoi((*argv)[1]);
                        argc--;
                        (*argv)++;
                    } catch(std::logic_error&) {
                        stringstream err;
                        err << "foo must be an integer. Found foo = " << argv[1] << endl;
                        throw CLIParsingError(err.str());
                    }

                    cout << "--foo option provided with value: " << fooArg << endl;
                } else return false;

                return true;
            }

            default: cerr << "Unrecognized command line argument: " << (*argv)[0] << endl;
        }
    }

    return false;
}

string PseaudoTp1BlockCode::onInterfaceDraw() {
    stringstream trace;
    trace << "Some value " << 123;
    return trace.str();
}
