#include "catomsTpBlockCode.hpp"
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <algorithm>

using namespace Catoms3D;


Cell3DPosition CatomsTpBlockCode::initiator  = Cell3DPosition(6, 4, 5);

Cell3DPosition CatomsTpBlockCode::Origin  = Cell3DPosition(4, 4, 2);
Cell3DPosition CatomsTpBlockCode::OriginB = Cell3DPosition(16, 4, 2);

static const std::array<Cell3DPosition, 12> FB_RELATIVE_POSITIONS = {
    Cell3DPosition(-2, -1, 3), Cell3DPosition(-1, -1, 2), Cell3DPosition(-2, -1, 1),
    Cell3DPosition(-1, -1, 3), Cell3DPosition(-1, -1, 1), Cell3DPosition(0, 0, 4),
    Cell3DPosition(0, 0, 0),   Cell3DPosition(1, 0, 4),   Cell3DPosition(1, 0, 0),
    Cell3DPosition(1, 0, 3),   Cell3DPosition(1, 0, 1),   Cell3DPosition(2, 1, 2)
};

// Test
static const std::array<Cell3DPosition, 12> BF_RELATIVE_POSITIONS = {
    Cell3DPosition(-2, 0, 3),  Cell3DPosition(-1, 1, 2),  Cell3DPosition(-2, 0, 1),
    Cell3DPosition(-1, 0, 3),  Cell3DPosition(-1, 0, 1),  Cell3DPosition(0, 0, 4),
    Cell3DPosition(0, 0, 0),   Cell3DPosition(1, 0, 4),   Cell3DPosition(1, 0, 0),
    Cell3DPosition(1, -1, 3),  Cell3DPosition(1, -1, 1),  Cell3DPosition(2, -1, 2)
};

static std::array<Cell3DPosition, 12> gFBAbsPositions;
static bool gFBAbsBuilt = false;


static std::array<Cell3DPosition, 12> gBFAbsPositions;
static bool gBFAbsBuilt = false;

static int gFirstWave = 0;
static int gReachedWave = 0;


// ---------------------------
// Constructor: register message handlers only
// ---------------------------
CatomsTpBlockCode::CatomsTpBlockCode(Catoms3DBlock *host) : Catoms3DBlockCode(host) {
    if (!host) return;

    addMessageEventFunc2(GO_ID,   std::bind(&CatomsTpBlockCode::handleGo,   this,
                                            std::placeholders::_1, std::placeholders::_2));
    addMessageEventFunc2(BACK_ID, std::bind(&CatomsTpBlockCode::handleBack, this,
                                            std::placeholders::_1, std::placeholders::_2));
    addMessageEventFunc2(FIRST_ID,
        std::bind(&CatomsTpBlockCode::handleFirst, this,
                  std::placeholders::_1, std::placeholders::_2));
    addMessageEventFunc2(REACHED_ID,
        std::bind(&CatomsTpBlockCode::handleReached, this,
                  std::placeholders::_1, std::placeholders::_2));



    module = static_cast<Catoms3DBlock*>(hostBlock);
}

// ---------------------------
// Minimal startup (no assignments, no coloring)



void CatomsTpBlockCode::startup() {
    // Origin: compute + print FB, then also compute + print BF (FB shifted by +16X)
    if (module->position == initiator) {
        if (!gFBAbsBuilt) {
            for (size_t i = 0; i < FB_RELATIVE_POSITIONS.size(); ++i)
                gFBAbsPositions[i] = Origin + FB_RELATIVE_POSITIONS[i];
            gFBAbsBuilt = true;

            for (size_t i = 0; i < gFBAbsPositions.size(); ++i)
                console << "[FBAbs] i=" << i << " -> " << gFBAbsPositions[i] << "\n";
        }

        if (!gBFAbsBuilt) {
            gBFAbsPositions = getTargetFBPlus16X();
            gBFAbsBuilt = true;

            for (size_t i = 0; i < gBFAbsPositions.size(); ++i)
                console << "[BFAbs] i=" << i << " -> " << gBFAbsPositions[i] << "  (FB+16X)\n";
        }

        setColor(RED);
        // optional: still kick the FIRST wave toward the first FB target
        if (!gFBAbsPositions.empty())   broadcastFirstTo(gFBAbsPositions[0], gBFAbsPositions[0]);

        return; // done for Origin
    }
    if (module->position == Origin) {
        setColor(YELLOW);
        return;
    }

    // OriginB: no calculations anymore (just mark visually if desired)
    if (module->position == OriginB) {
        setColor(BLUE);
        return;
    }

    // Everyone else
    setColor(LIGHTGREY);
}



void CatomsTpBlockCode::broadcastFirstTo(const Cell3DPosition& target,
                                         const Cell3DPosition& goal) {
    if (module->position != initiator) return;  // only Origin initiates
    CFirstPayload fp{ target, goal, ++gFirstWave };
    sendMessageToAllNeighbors(
        "FIRST_fwd",
        new MessageOf<CFirstPayload>(FIRST_ID, fp),
        1000, 100, 0
    );
}


void CatomsTpBlockCode::handleFirst(std::shared_ptr<Message> _msg, P2PNetworkInterface* sender) {
    auto* m  = static_cast<MessageOf<CFirstPayload>*>(_msg.get());
    CFirstPayload fp = *m->getData();

    // If I am the addressed (target) module, create path then move
    if (module->position == fp.target) {
        setColor(GREEN);
        Cell3DPosition start = module->position;
        Cell3DPosition goal  = fp.goal;

        console << "[FIRST] I am the target at " << start
                << " — computing path to " << goal << "\n";

        std::vector<Cell3DPosition> path;

        if (reversePhase && !currentPath.empty()) {
            // reverse and reuse previous path
            path = currentPath;
            std::reverse(path.begin(), path.end());
            console << "[REVERSE] Reusing previous path in reverse order ("
                    << path.size() << " steps)\n";
        } else {
            // normal phase: compute forward path
            path = findPath(start, goal);
        }

        if (!path.empty()) {
            // Kick off first motion
            pathIdx = 0;
            if (!currentPath.empty() && currentPath[0] == start) pathIdx = 1;

            if (pathIdx < static_cast<int>(currentPath.size())) {
                Cell3DPosition nextPos = currentPath[pathIdx];
                console << "[FIRST] Path found (" << currentPath.size()
                        << " steps). First move to " << nextPos << "\n";
                getScheduler()->schedule(new Catoms3DRotationStartEvent(
                    getScheduler()->now() + 100, module, nextPos));
            } else {
                console << "[FIRST] Path computed but already at goal.\n";
                hasPath = false;
            }
        } else {
            console << "[FIRST] No path found from " << start << " to " << goal << "\n";
        }
        return; // do NOT forward
    }

    // Everyone else: forward once per wave (natural stop)
    if (fp.wave <= seenFirstWave) return;
    seenFirstWave = fp.wave;

    sendMessageToAllNeighbors(
        "FIRST_fwd",
        new MessageOf<CFirstPayload>(FIRST_ID, fp),
        1000, 100, 1, sender
    );
}


void CatomsTpBlockCode::handleReached(std::shared_ptr<Message> _msg, P2PNetworkInterface* sender) {
    auto* m = static_cast<MessageOf<CReachedPayload>*>(_msg.get());
    CReachedPayload rp = *m->getData();

    // avoid duplicates
    if (rp.wave <= seenReachedWave) return;
    seenReachedWave = rp.wave;

    // Only initiator handles orchestration
    if (module->position == rp.origin) {
        // ========== REVERSE PHASE HANDLING ==========
        if (reversePhase) {
            console << "[REVERSE] Module at " << rp.from
                    << " finished reverse motion. Proceeding to previous index.\n";

            reverseIndex--;
            if (reverseIndex >= 0) {
                Cell3DPosition nextTarget = gBFAbsPositions[reverseIndex];
                Cell3DPosition nextGoal   = gFBAbsPositions[reverseIndex];

                console << "[REVERSE] Launching next reverse module " << reverseIndex
                        << " from " << nextTarget << " → " << nextGoal << "\n";

                broadcastFirstTo(nextTarget, nextGoal);
            } else {
                console << "[REVERSE] Reverse phase completed — all modules returned!\n";
                reversePhase = false;
                setColor(PURPLE);
            }
            return; // ✅ done handling reverse-phase
        }

        // ========== FORWARD PHASE HANDLING ==========
        console << "[REACHED] Module at " << rp.from << " reports: reached target.\n";
        setColor(ORANGE);

        nextPairIdx++;
        if (nextPairIdx < static_cast<int>(gFBAbsPositions.size())) {
            Cell3DPosition nextTarget = gFBAbsPositions[nextPairIdx];
            Cell3DPosition nextGoal   = gBFAbsPositions[nextPairIdx];

            console << "[INITIATOR] Launching next module " << nextPairIdx
                    << " from " << nextTarget << " → " << nextGoal << "\n";
            broadcastFirstTo(nextTarget, nextGoal);
        } else {
            console << "[ORIGIN] All modules have completed their moves!\n";
            setColor(PURPLE);
            allReached = true;
            console << "[INITIATOR] Flag allReached = true\n";

            // Start reverse phase
            reversePhase = true;
            reverseIndex = static_cast<int>(gFBAbsPositions.size()) - 1;

            Cell3DPosition target = gBFAbsPositions[reverseIndex];
            Cell3DPosition goal   = gFBAbsPositions[reverseIndex];

            console << "[REUSE] Starting reverse phase with module " << reverseIndex
                    << " : target=" << target << " , goal=" << goal << "\n";

            broadcastFirstTo(target, goal);
        }
        return;
    }

    // Other modules just forward REACHED messages
    sendMessageToAllNeighbors(
        "REACHED_fwd",
        new MessageOf<CReachedPayload>(REACHED_ID, rp),
        1000, 100, 1, sender
    );
}



// ---------------------------
// Message: GO (tree building for farthest-node selection)
// ---------------------------
void CatomsTpBlockCode::handleGo(std::shared_ptr<Message> _msg, P2PNetworkInterface* sender) {
    auto* m = static_cast<MessageOf<std::pair<int,int>>*>(_msg.get());
    auto [msgStage, msgDist] = *m->getData();

    if (msgStage > stage) { // new wave
        stage = msgStage;
        initFarthest();
    }

    if (parent == nullptr || msgDist < myDist) {
        parent = sender;
        myDist = msgDist;

        nbWaitedAns = sendMessageToAllNeighbors(
            "GO-fwd",
            new MessageOf<std::pair<int,int>>(GO_ID, {stage, myDist + 1}),
            1000, 100, 1, parent);

        if (nbWaitedAns == 0 && parent) {
            CBackPayload b{0, myDist, module->blockId};
            sendMessage("BACK_UP", new MessageOf<CBackPayload>(BACK_ID, b), parent, 100, 100);
        }
    } else {
        CBackPayload rej{0, myDist, module->blockId};
        sendMessage("BACK_reject", new MessageOf<CBackPayload>(BACK_ID, rej), sender, 100, 100);
    }
}

// ---------------------------
// Message: BACK (aggregation + select-down of the farthest)
// ---------------------------
void CatomsTpBlockCode::handleBack(std::shared_ptr<Message> _msg, P2PNetworkInterface* sender) {
    auto* m = static_cast<MessageOf<CBackPayload>*>(_msg.get());
    CBackPayload bp = *m->getData();

    // SELECT-DOWN propagation
    if (bp.kind == 1) {
        if (module->blockId == bp.id) {
            // This node is the selected farthest one.
            // If a path is already prepared, start executing it.
            if (hasPath && !currentPath.empty()) {
                const Cell3DPosition start = module->position;

                // Start from the next waypoint after current position if present
                pathIdx = 0;
                if (!currentPath.empty() && currentPath[0] == start) {
                    pathIdx = 1;
                } else {
                    for (size_t i = 0; i < currentPath.size(); ++i) {
                        if (currentPath[i] == start) { pathIdx = static_cast<int>(i) + 1; break; }
                    }
                }

                if (pathIdx < static_cast<int>(currentPath.size())) {
                    Cell3DPosition nextPos = currentPath[pathIdx];
                    getScheduler()->schedule(new Catoms3DRotationStartEvent(
                        getScheduler()->now() + 100, module, nextPos));
                }
            }
        } else if (winnerChild) {
            sendMessage("SELECT_DOWN",
                        new MessageOf<CBackPayload>(BACK_ID, bp),
                        winnerChild, 100, 100);
        }
        return; // do not count against nbWaitedAns
    }

    // Regular BACK_UP from a child: update best candidate
    if (bp.dist > bestDist || (bp.dist == bestDist && bp.id < bestId)) {
        bestDist    = bp.dist;
        bestId      = bp.id;
        winnerChild = sender;
    }

    // Count children; when all replied, send result upward or start select-down at root
    nbWaitedAns--;
    if (nbWaitedAns == 0) {
        if (parent) {
            // Compare myself as candidate as well
            if (myDist > bestDist || (myDist == bestDist && module->blockId < bestId)) {
                bestDist    = myDist;
                bestId      = module->blockId;
                winnerChild = nullptr;
            }
            CBackPayload up{0, bestDist, bestId};
            sendMessage("BACK_UP", new MessageOf<CBackPayload>(BACK_ID, up), parent, 100, 100);
        } else {
            // Root: announce winner and start select-down
            if (winnerChild) {
                CBackPayload sel{1, bestDist, bestId};
                sendMessage("SELECT_DOWN",
                            new MessageOf<CBackPayload>(BACK_ID, sel),
                            winnerChild, 100, 100);
            } else {
                // Root itself is the winner (isolated case). If it already has a path, start it.
                if (hasPath && !currentPath.empty()) {
                    const Cell3DPosition start = module->position;
                    pathIdx = 0;
                    if (!currentPath.empty() && currentPath[0] == start) {
                        pathIdx = 1;
                    } else {
                        for (size_t i = 0; i < currentPath.size(); ++i) {
                            if (currentPath[i] == start) { pathIdx = static_cast<int>(i) + 1; break; }
                        }
                    }
                    if (pathIdx < static_cast<int>(currentPath.size())) {
                        Cell3DPosition nextPos = currentPath[pathIdx];
                        getScheduler()->schedule(new Catoms3DRotationStartEvent(
                            getScheduler()->now() + 100, module, nextPos));
                    }
                }
            }
        }
    }
}

// ---------------------------
// Motion continuation: follow currentPath
// ---------------------------
void CatomsTpBlockCode::onMotionEnd() {
    if (!hasPath) return;

    // advance to the next waypoint
    pathIdx++;

    // Skip any waypoints equal to our *current* position
    while (pathIdx < static_cast<int>(currentPath.size()) &&
           currentPath[pathIdx] == module->position) {
        pathIdx++;
    }

    if (pathIdx < static_cast<int>(currentPath.size())) {
        // schedule next step
        Cell3DPosition nextPos = currentPath[pathIdx];
        console << "[MOVE] Next step " << pathIdx << "/" << currentPath.size()
                << " → " << nextPos << "\n";
        getScheduler()->schedule(new Catoms3DRotationStartEvent(
            getScheduler()->now() + 100, module, nextPos));
    } else {
        // finished
        hasPath = false;
        console << "[MOVE] Reached final waypoint at " << module->position << "\n";

        if (module->position != initiator) {
            // Normal case: notify initiator
            console << "[REACHED] Notifying Initiator...\n";
            CReachedPayload rp{ initiator, module->position, ++gReachedWave };

            sendMessageToAllNeighbors(
                "REACHED_fwd",
                new MessageOf<CReachedPayload>(REACHED_ID, rp),
                1000, 100, 0);
        } else {
            // Origin case: continue sequence directly (no REACHED message)
            console << "[ORIGIN] Reached my goal. Launching next module...\n";
            setColor(ORANGE);

            nextPairIdx++;
            if (nextPairIdx < static_cast<int>(gFBAbsPositions.size())) {
                Cell3DPosition nextTarget = gFBAbsPositions[nextPairIdx];
                Cell3DPosition nextGoal   = gBFAbsPositions[nextPairIdx];



                console << "[ORIGIN] Launching next module " << nextPairIdx
                        << " from " << nextTarget << " → " << nextGoal << "\n";
                broadcastFirstTo(nextTarget, nextGoal);
            } else {
                console << "[ORIGIN] All modules have completed their moves!\n";
                setColor(PURPLE);
            }
        }
    }
}



// ---------------------------
// BFS pathfinding over motion rules
// ---------------------------
std::vector<Cell3DPosition> CatomsTpBlockCode::findPath(Cell3DPosition &start,
                                                        Cell3DPosition &goal) {
    std::vector<Cell3DPosition> path;
    std::set<Cell3DPosition> visited;
    std::map<Cell3DPosition, Cell3DPosition> parentMap;
    std::queue<Cell3DPosition> q;

    q.push(start);
    visited.insert(start);

    bool found = false;

    while (!q.empty() && !found) {
        Cell3DPosition current = q.front();
        q.pop();

        if (current == goal) { found = true; break; }

        std::vector<Cell3DPosition> reachablePositions;
        bool success = getAllPossibleMotionsFromPosition(current, reachablePositions);

        if (success) {
            for (auto &pos : reachablePositions) {
                if (visited.find(pos) == visited.end()) {
                    visited.insert(pos);
                    parentMap[pos] = current;
                    q.push(pos);
                }
            }
        }
    }

    if (found) {
        Cell3DPosition step = goal;
        while (step != start) {
            path.push_back(step);
            step = parentMap[step];
        }
        std::reverse(path.begin(), path.end());
        currentPath = path; // store for motion
        hasPath = !currentPath.empty();
        pathIdx = 0;
    }

    return path;
}

// ---------------------------
// Enumerate all reachable moves from a given position
// ---------------------------
bool CatomsTpBlockCode::getAllPossibleMotionsFromPosition(
    Cell3DPosition position,
    std::vector<Cell3DPosition> &reachablePositions) {

    Catoms3DBlock* mod = static_cast<Catoms3DBlock*>(lattice->getBlock(position));
    if (mod) {
        for (auto &neighPos: lattice->getFreeNeighborCells(position)) {
            if (mod->canMoveTo(neighPos)) {
                reachablePositions.push_back(neighPos);
            }
        }
        return !reachablePositions.empty();
    }

    bool found = false;
    for (auto &neighPos: lattice->getActiveNeighborCells(position)) {
        Catoms3DBlock* neigh = static_cast<Catoms3DBlock*>(lattice->getBlock(neighPos));
        std::vector<Catoms3DMotionRulesLink*> vec;
        Catoms3DMotionRules motionRulesInstance;
        short conFrom = neigh->getConnectorId(position);
        motionRulesInstance.getValidMotionListFromPivot(
            neigh, conFrom, vec, static_cast<FCCLattice*>(lattice), nullptr);
        for (auto link: vec) {
            Cell3DPosition toPos;
            neigh->getNeighborPos(link->getConToID(), toPos);
            reachablePositions.push_back(toPos);
            found = true;
        }
    }
    return found;
}

std::array<Cell3DPosition, 12> CatomsTpBlockCode::getTargetFBPlus16X() const {
    std::array<Cell3DPosition, 12> out{};

    // Build absolute FB positions from Origin …
    for (size_t i = 0; i < FB_RELATIVE_POSITIONS.size(); ++i) {
        out[i] = Origin + FB_RELATIVE_POSITIONS[i];
    }
    // … then shift by +16 on X
    const Cell3DPosition shift(16, 0, 0);
    for (auto &p : out) p = p + shift;

    return out;
}



// ---------------------------
// Start a new farthest-node wave from this module
// ---------------------------
void CatomsTpBlockCode::startFarthestWaveFromHere() {
    if (farthestWaveStarted) return;
    farthestWaveStarted = true;

    stage++;
    initFarthest();
    myDist = 0;
    parent = nullptr;

    nbWaitedAns = sendMessageToAllNeighbors(
        "GO", new MessageOf<std::pair<int,int>>(GO_ID, {stage, 0}),
        1000, 100, 0);

    if (nbWaitedAns == 0) { // isolated root
        bestDist = myDist;
        bestId   = module->blockId;
    }
}



// ---------------------------
// Required virtuals (stubbed so the linker is happy)
// ---------------------------
bool CatomsTpBlockCode::parseUserCommandLineArgument(int &argc, char **argv[]) {
    (void)argc; (void)argv; // unused
    return false;
}

void CatomsTpBlockCode::processLocalEvent(EventPtr pev) {
    // Keep base behaviour; no extra local processing needed in pruned build
    Catoms3DBlockCode::processLocalEvent(pev);
}

void CatomsTpBlockCode::onBlockSelected() {
    // no-op
}

void CatomsTpBlockCode::onAssertTriggered() {
    // no-op
}

std::string CatomsTpBlockCode::onInterfaceDraw() {
    return std::string();
}
